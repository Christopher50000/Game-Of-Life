
public interface ICell  {
	
	

	public void NextGenCell(boolean newstate);
	public boolean GetState();
	public boolean GetNextGenCell();


	
}

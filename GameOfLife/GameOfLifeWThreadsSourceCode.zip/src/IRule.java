
public interface IRule {

	public boolean GetNextGen(int row,int column);


}

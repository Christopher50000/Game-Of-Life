
public interface InputFromFile {

	public boolean [][] getBoolTable();
	
	public int returnGens();
		

}
